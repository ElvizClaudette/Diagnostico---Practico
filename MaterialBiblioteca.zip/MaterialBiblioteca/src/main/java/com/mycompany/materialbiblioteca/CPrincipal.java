/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.materialbiblioteca;

/**
 *
 * @author 52221
 */
public class CPrincipal {
    public static void main(String[] args) {
        
      MaterialBiblioteca p1 = new MaterialBiblioteca("Paquete 1","tec",2022 );
      MaterialBiblioteca p2= new MaterialBiblioteca("Paquete 2","tec",2023 );
      
    Libro l1= new Libro( 12,328,"El Quijote","Mario Oca",2022 );
    Libro l2= new Libro( 16,224,"Desarrollo personal","Mario Oca",2022 );
    Libro l3= new Libro( 14,124,"El Porque de las cosas","Mario Oca",2022 );
    
    Libro l4= new Libro( 68,440,"Fundamentos de programación","Alicia linux",2023 );
    Libro l5= new Libro( 12,125,"C++","Alixa linux",2023 );
    
    
    Revista R1= new Revista("Deporte","lo mas importante","lex", 2022);
    Revista R2= new Revista("Celebridades","A que no te enteraste","lex", 2022);
    Revista R3= new Revista("infantil","el coco","Juliana limon", 2022);
    
    
    DVD D1= new DVD(2,"frozen","tec",2023);
    DVD D2= new DVD(4,"El apocalisis","tec",2023);
    
    
    Libro[] Libros2022={l1,l2,l3};
    Libro[] Libros2023={l4,l5};
    
    
    MaterialBiblioteca a1= new MaterialBiblioteca();
    
    
    a1.setColeccionLibro(Libros2022,Libros2023);
    
    Revista [] RevistasLex={R1,R2};
    Revista[] RevistaJuliana={R3};
    
    a1.setColecionRevista(RevistasLex,RevistaJuliana);
    
    
    
    DVD[] DVD1={D1,D2};
    a1.setCollecionDVD(DVD1);
    
   
    
    
    
    
    
    
    
    
    
            
    
            
       
        
    }
    
    
    
}
