/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.materialbiblioteca;

/**
 *
 * @author 52221
 */
public class DVD extends MaterialBiblioteca{
    private int tiempoRepruduccion;

    public DVD(int tiempoRepruduccion, String titulo, String autor, int Publicacion) {
        super(titulo, autor, Publicacion);
        this.tiempoRepruduccion = tiempoRepruduccion;
    }

    public int getTiempoRepruduccion() {
        return tiempoRepruduccion;
    }

    public void setTiempoRepruduccion(int tiempoRepruduccion) {
        this.tiempoRepruduccion = tiempoRepruduccion;
    }
    
    
    
    
    
    
    
    
}
