/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.materialbiblioteca;

/**
 *
 * @author 52221
 */
public class Revista extends MaterialBiblioteca{
    
  private String categoria;

    public Revista(String categoria, String titulo, String autor, int Publicacion) {
        super(titulo, autor, Publicacion);
        this.categoria = categoria;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

  
  
    
}
