/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.materialbiblioteca;

/**
 *
 * @author 52221
 */
public class Libro extends MaterialBiblioteca {
    int CantidadLibrosDisponibles;
    int numeroPaginas;

    public Libro(int CantidadLibrosDisponibles, int numeroPaginas, String titulo, String autor, int Publicacion) {
        super(titulo, autor, Publicacion);
        this.CantidadLibrosDisponibles = CantidadLibrosDisponibles;
        this.numeroPaginas = numeroPaginas;
    }

    public int getCantidadLibrosDisponibles() {
        return CantidadLibrosDisponibles;
    }

    public void setCantidadLibrosDisponibles(int CantidadLibrosDisponibles) {
        this.CantidadLibrosDisponibles = CantidadLibrosDisponibles;
    }

    public int getNumeroPaginas() {
        return numeroPaginas;
    }

    public void setNumeroPaginas(int numeroPaginas) {
        this.numeroPaginas = numeroPaginas;
    }
    
    
    
    
    
}
