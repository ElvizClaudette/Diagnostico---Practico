/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.materialbiblioteca;

/**
 *
 * @author 52221
 */
public class MaterialBiblioteca {
    private String titulo;
    private String  autor;
    private int Publicacion;
    
    private Libro[] ColeccionLibro;
    private Revista[] colecionRevista;
    private DVD[] collecionDVD;
    

    public MaterialBiblioteca() {
    }

    public MaterialBiblioteca(String titulo, String autor, int Publicacion) {
        this.titulo = titulo;
        this.autor = autor;
        this.Publicacion = Publicacion;
    }

    public MaterialBiblioteca(Libro[] ColeccionLibro, Revista[] colecionRevista, DVD[] collecionDVD) {
        this.ColeccionLibro = ColeccionLibro;
        this.colecionRevista = colecionRevista;
        this.collecionDVD = collecionDVD;
    }

    public Libro[] getColeccionLibro() {
        return ColeccionLibro;
    }

    public void setColeccionLibro(Libro[] ColeccionLibro) {
        this.ColeccionLibro = ColeccionLibro;
    }

    public Revista[] getColecionRevista() {
        return colecionRevista;
    }

    public void setColecionRevista(Revista[] colecionRevista) {
        this.colecionRevista = colecionRevista;
    }

    public DVD[] getCollecionDVD() {
        return collecionDVD;
    }

    public void setCollecionDVD(DVD[] collecionDVD) {
        this.collecionDVD = collecionDVD;
    }


    
    
    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getPublicacion() {
        return Publicacion;
    }

    public void setPublicacion(int Publicacion) {
        this.Publicacion = Publicacion;
    }

    void setColeccionLibro(Libro[] Libros2022, Libro[] Libros2023) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    void setColecionRevista(Revista[] RevistasLex, Revista[] RevistaJuliana) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    
   

}
